
import React, { useState, useContext } from 'react';
import { 
  Filter, 
  Download, 
  Phone, 
  Check, 
  X, 
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  ShieldAlert,
  User,
  Plus,
  MapPin,
  DollarSign,
  Smartphone,
  Lock,
  Link2,
  RefreshCw
} from 'lucide-react';
import { OrderStatus, RiskLevel } from '../types';
import { ShopifyContext } from '../App';

const initialOrders = [
  { id: '#8923', customer: 'Juan Perez', city: 'Bogotá', total: '$45.00', status: OrderStatus.PENDING_CALL, risk: RiskLevel.LOW, date: '10:24 AM' },
  { id: '#8924', customer: 'Maria Garcia', city: 'Medellín', total: '$89.90', status: OrderStatus.UNCONFIRMED, risk: RiskLevel.MEDIUM, date: '11:15 AM' },
  { id: '#8925', customer: 'Roberto Gomez', city: 'Cali', total: '$120.00', status: OrderStatus.CONFIRMED, risk: RiskLevel.LOW, date: '12:05 PM' },
  { id: '#8926', customer: 'Andres Sosa', city: 'Barranquilla', total: '$32.50', status: OrderStatus.SHIPPED, risk: RiskLevel.HIGH, date: '01:30 PM' },
  { id: '#8927', customer: 'Elena Rincon', city: 'Bogotá', total: '$55.00', status: OrderStatus.DELIVERED, risk: RiskLevel.LOW, date: '02:45 PM' },
  { id: '#8928', customer: 'Luis Mendez', city: 'Cartagena', total: '$78.00', status: OrderStatus.CANCELLED, risk: RiskLevel.BLACKLISTED, date: '03:10 PM' },
];

const StatusBadge = ({ status }: { status: OrderStatus }) => {
  const colors: Record<OrderStatus, string> = {
    [OrderStatus.UNCONFIRMED]: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
    [OrderStatus.PENDING_CALL]: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
    [OrderStatus.CONFIRMED]: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    [OrderStatus.SHIPPED]: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20',
    [OrderStatus.DELIVERED]: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    [OrderStatus.CANCELLED]: 'bg-red-500/10 text-red-400 border-red-500/20',
    [OrderStatus.FAILED]: 'bg-red-600/10 text-red-500 border-red-600/20',
  };

  return (
    <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${colors[status]}`}>
      {status}
    </span>
  );
};

const RiskBadge = ({ risk }: { risk: RiskLevel }) => {
  const icons: Record<RiskLevel, React.ReactNode> = {
    [RiskLevel.LOW]: <ShieldCheck size={14} className="text-emerald-400" />,
    [RiskLevel.MEDIUM]: <ShieldAlert size={14} className="text-orange-400" />,
    [RiskLevel.HIGH]: <ShieldAlert size={14} className="text-red-400" />,
    [RiskLevel.BLACKLISTED]: <ShieldAlert size={14} className="text-red-600" />,
  };

  const colors: Record<RiskLevel, string> = {
    [RiskLevel.LOW]: 'text-emerald-400 bg-emerald-400/10',
    [RiskLevel.MEDIUM]: 'text-orange-400 bg-orange-400/10',
    [RiskLevel.HIGH]: 'text-red-400 bg-red-400/10',
    [RiskLevel.BLACKLISTED]: 'text-red-600 bg-red-600/10',
  };

  return (
    <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded-lg ${colors[risk]}`}>
      {icons[risk]}
      <span className="text-[10px] font-bold uppercase tracking-wider">{risk}</span>
    </div>
  );
};

const Orders: React.FC = () => {
  const context = useContext(ShopifyContext);
  const isConnected = context?.isConnected ?? false;
  
  const [orders, setOrders] = useState(initialOrders);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSyncModalOpen, setIsSyncModalOpen] = useState(false);
  const [syncForm, setSyncForm] = useState({ domain: '', token: '' });
  const [isSyncing, setIsSyncing] = useState(false);

  const [newOrder, setNewOrder] = useState({
    customer: '',
    phone: '',
    city: '',
    total: '',
    risk: RiskLevel.LOW
  });

  const handleManualOrderClick = () => {
    if (!isConnected) {
      setIsSyncModalOpen(true);
    } else {
      setIsModalOpen(true);
    }
  };

  const handleSyncShopify = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSyncing(true);
    // Simulación de validación de API Shopify
    setTimeout(() => {
      context?.setIsConnected(true);
      context?.setShopDomain(syncForm.domain.includes('.') ? syncForm.domain : `${syncForm.domain}.myshopify.com`);
      setIsSyncing(false);
      setIsSyncModalOpen(false);
      setIsModalOpen(true); // Abrimos el modal de orden inmediatamente después de sincronizar
    }, 2000);
  };

  const handleAddOrder = (e: React.FormEvent) => {
    e.preventDefault();
    const id = `#${Math.floor(Math.random() * 9000) + 1000}`;
    const date = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    const formattedOrder = {
      id,
      customer: newOrder.customer,
      city: newOrder.city,
      total: `$${parseFloat(newOrder.total).toFixed(2)}`,
      status: OrderStatus.UNCONFIRMED,
      risk: newOrder.risk,
      date
    };

    setOrders([formattedOrder, ...orders]);
    setIsModalOpen(false);
    setNewOrder({ customer: '', phone: '', city: '', total: '', risk: RiskLevel.LOW });
  };

  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500 relative">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Gestión de Pedidos</h1>
          <p className="text-slate-400 mt-1">Control logístico y confirmación de ventas COD</p>
        </div>
        <div className="flex gap-3">
          <button className="bg-slate-900 border border-slate-800 px-4 py-2 rounded-xl text-sm font-semibold flex items-center gap-2 hover:bg-slate-800 transition-all">
            <Download size={18} /> Exportar CSV
          </button>
          <button 
            onClick={handleManualOrderClick}
            className={`${isConnected ? 'blue-gradient' : 'bg-slate-800 cursor-not-allowed'} px-6 py-2 rounded-xl text-sm font-bold shadow-lg flex items-center gap-2 hover:brightness-110 active:scale-95 transition-all relative overflow-hidden group`}
          >
            {isConnected ? <Plus size={18} /> : <Lock size={16} className="text-slate-500" />}
            Nueva Orden Manual
            {!isConnected && (
              <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                 <span className="text-[10px] font-black uppercase text-blue-400 tracking-tighter">Requiere Shopify Sync</span>
              </div>
            )}
          </button>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="dark-glass rounded-2xl p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex gap-2">
          {['Hoy', 'Ayer', '7 Días', '30 Días'].map((t) => (
            <button key={t} className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${t === 'Hoy' ? 'bg-blue-600 text-white' : 'hover:bg-slate-800 text-slate-400'}`}>
              {t}
            </button>
          ))}
        </div>
        <div className="flex gap-3">
          <div className="relative">
            <Filter size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <select className="bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none cursor-pointer">
              <option>Todos los Estados</option>
              {Object.values(OrderStatus).map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* Advanced Table */}
      <div className="dark-glass rounded-2xl overflow-hidden border border-slate-800/50 shadow-2xl relative">
        {!isConnected && (
          <div className="absolute inset-0 z-20 bg-slate-950/40 backdrop-blur-[2px] flex items-center justify-center">
             <div className="bg-slate-900/90 border border-slate-800 p-8 rounded-[2rem] text-center max-w-sm shadow-2xl">
                <div className="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-blue-500/20">
                  <Link2 className="text-blue-400" size={32} />
                </div>
                <h3 className="text-lg font-bold mb-2">Conexión Requerida</h3>
                <p className="text-xs text-slate-500 mb-6 leading-relaxed">
                  Para ver y crear pedidos reales, debes vincular tu tienda Shopify. Esto permite validar stock, precios y clientes automáticamente.
                </p>
                <button 
                  onClick={() => setIsSyncModalOpen(true)}
                  className="w-full blue-gradient py-3 rounded-xl text-xs font-black uppercase tracking-widest shadow-lg shadow-blue-500/20"
                >
                  SINCRONIZAR TIENDA
                </button>
             </div>
          </div>
        )}
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-900/50 border-b border-slate-800">
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Orden</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Cliente / Ciudad</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Estado</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Riesgo AI</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider">Total</th>
              <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider text-right">Acciones Rápidas</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/50">
            {orders.map((order) => (
              <tr key={order.id} className="hover:bg-slate-800/30 transition-colors group">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-blue-400">{order.id}</span>
                    <span className="text-[10px] font-medium text-slate-600">{order.date}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div>
                    <p className="text-sm font-semibold">{order.customer}</p>
                    <p className="text-xs text-slate-500">{order.city}</p>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <StatusBadge status={order.status} />
                </td>
                <td className="px-6 py-4">
                  <RiskBadge risk={order.risk} />
                </td>
                <td className="px-6 py-4 font-bold text-sm">
                  {order.total}
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="p-2 bg-blue-500/10 text-blue-400 rounded-lg hover:bg-blue-500 hover:text-white transition-all">
                      <Phone size={16} />
                    </button>
                    <button className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg hover:bg-emerald-500 hover:text-white transition-all">
                      <Check size={16} />
                    </button>
                    <button className="p-2 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500 hover:text-white transition-all">
                      <X size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal de Sincronización Shopify (Sync Gate) */}
      {isSyncModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-slate-950/90 backdrop-blur-md"
            onClick={() => !isSyncing && setIsSyncModalOpen(false)}
          ></div>
          <div className="relative dark-glass w-full max-w-md rounded-[2.5rem] shadow-2xl border border-blue-500/30 overflow-hidden animate-in slide-in-from-top-4 duration-300">
            <div className="p-10 text-center">
               <div className="w-20 h-20 blue-gradient rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-blue-500/40 transform -rotate-12">
                  <RefreshCw className={`text-white ${isSyncing ? 'animate-spin' : ''}`} size={40} />
               </div>
               <h2 className="text-2xl font-black mb-2">Sync Real-Time</h2>
               <p className="text-slate-400 text-sm mb-8">Conecta tu tienda oficial para habilitar todas las herramientas operativas de RealProfit.</p>

               <form onSubmit={handleSyncShopify} className="space-y-4 text-left">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Shopify Domain</label>
                    <div className="relative group">
                      <Link2 size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-400 transition-colors" />
                      <input 
                        required
                        type="text" 
                        placeholder="ejemplo.myshopify.com" 
                        value={syncForm.domain}
                        onChange={e => setSyncForm({...syncForm, domain: e.target.value})}
                        className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-mono"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Access Token (Admin API)</label>
                    <div className="relative group">
                      <Lock size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-400 transition-colors" />
                      <input 
                        required
                        type="password" 
                        placeholder="shpat_xxxxxxxxxxxxxxxx" 
                        value={syncForm.token}
                        onChange={e => setSyncForm({...syncForm, token: e.target.value})}
                        className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all font-mono"
                      />
                    </div>
                  </div>

                  <button 
                    disabled={isSyncing}
                    type="submit"
                    className="w-full blue-gradient py-5 rounded-2xl font-black text-sm uppercase tracking-[0.2em] shadow-xl shadow-blue-600/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-3 disabled:opacity-50 disabled:grayscale"
                  >
                    {isSyncing ? (
                      <>
                        <RefreshCw className="animate-spin" size={20} />
                        VERIFICANDO...
                      </>
                    ) : (
                      'AUTENTICAR Y ACTIVAR'
                    )}
                  </button>
               </form>

               <p className="mt-8 text-[10px] text-slate-600 font-bold uppercase tracking-widest">
                  🔒 Conexión Encriptada AES-256
               </p>
            </div>
          </div>
        </div>
      )}

      {/* Manual Order Modal (Solo accesible tras Sync) */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
            onClick={() => setIsModalOpen(false)}
          ></div>
          <div className="relative dark-glass w-full max-w-lg rounded-[2.5rem] shadow-2xl border border-white/10 overflow-hidden animate-in zoom-in duration-300">
            <div className="p-8">
              <div className="flex justify-between items-center mb-8">
                <div>
                  <h2 className="text-2xl font-black">Crear Orden Manual</h2>
                  <p className="text-slate-400 text-sm">Validado con: <span className="text-blue-400 font-mono text-xs">{context?.shopDomain}</span></p>
                </div>
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="p-2 hover:bg-slate-800 rounded-full text-slate-400 transition-all"
                >
                  <X size={24} />
                </button>
              </div>

              <form onSubmit={handleAddOrder} className="space-y-6">
                <div className="space-y-4">
                  <div className="relative group">
                    <User size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-400 transition-colors" />
                    <input 
                      required
                      type="text" 
                      placeholder="Nombre del Cliente" 
                      value={newOrder.customer}
                      onChange={e => setNewOrder({...newOrder, customer: e.target.value})}
                      className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 transition-all"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="relative group">
                      <Smartphone size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-400 transition-colors" />
                      <input 
                        required
                        type="tel" 
                        placeholder="Teléfono" 
                        value={newOrder.phone}
                        onChange={e => setNewOrder({...newOrder, phone: e.target.value})}
                        className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                      />
                    </div>
                    <div className="relative group">
                      <MapPin size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-400 transition-colors" />
                      <input 
                        required
                        type="text" 
                        placeholder="Ciudad" 
                        value={newOrder.city}
                        onChange={e => setNewOrder({...newOrder, city: e.target.value})}
                        className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                      />
                    </div>
                  </div>

                  <div className="relative group">
                    <DollarSign size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-blue-400 transition-colors" />
                    <input 
                      required
                      type="number" 
                      step="0.01"
                      placeholder="Valor Total de la Orden" 
                      value={newOrder.total}
                      onChange={e => setNewOrder({...newOrder, total: e.target.value})}
                      className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-4 pl-12 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-widest pl-1">Riesgo Inicial Estimado</label>
                    <div className="grid grid-cols-3 gap-3">
                      {[RiskLevel.LOW, RiskLevel.MEDIUM, RiskLevel.HIGH].map(level => (
                        <button
                          key={level}
                          type="button"
                          onClick={() => setNewOrder({...newOrder, risk: level})}
                          className={`py-3 rounded-xl text-[10px] font-black uppercase border transition-all ${
                            newOrder.risk === level 
                              ? 'bg-blue-600/20 border-blue-500 text-blue-400' 
                              : 'bg-slate-900 border-slate-800 text-slate-500 hover:border-slate-700'
                          }`}
                        >
                          {level}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="pt-4 flex gap-4">
                  <button 
                    type="button"
                    onClick={() => setIsModalOpen(false)}
                    className="flex-1 py-4 rounded-2xl font-bold text-slate-400 hover:bg-slate-800 transition-all"
                  >
                    Cancelar
                  </button>
                  <button 
                    type="submit"
                    className="flex-2 blue-gradient px-8 py-4 rounded-2xl font-black text-white shadow-xl shadow-blue-500/20 hover:brightness-110 active:scale-95 transition-all"
                  >
                    GUARDAR ORDEN
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Orders;
