
import React, { useState, useContext, useEffect } from 'react';
import { 
  Share2, 
  RefreshCw, 
  Settings2, 
  CheckCircle2, 
  XCircle, 
  Terminal,
  Clock,
  ExternalLink,
  ShieldCheck,
  Zap,
  Trash2,
  Database
} from 'lucide-react';
import { ShopifyContext } from '../App';

interface LogEntry {
  id: string;
  event: string;
  source: string;
  status: 'success' | 'error' | 'warning';
  timestamp: string;
}

const Integrations: React.FC = () => {
  const context = useContext(ShopifyContext);
  const isConnected = context?.isConnected ?? false;
  
  const [isSyncing, setIsSyncing] = useState(false);
  const [logs, setLogs] = useState<LogEntry[]>([
    { id: '1', event: 'Initial Fetch', source: 'Shopify API', status: 'success', timestamp: 'Hace 5 min' },
    { id: '2', event: 'Webhook: order/create', source: 'Shopify Webhook', status: 'success', timestamp: 'Hace 12 min' },
    { id: '3', event: 'Sync: Airtable', source: 'Automation', status: 'warning', timestamp: 'Hace 30 min' },
  ]);

  const handleManualSync = () => {
    setIsSyncing(true);
    // Real call to /api/shopify/sync would go here
    setTimeout(() => {
      setIsSyncing(false);
      setLogs([{ id: Date.now().toString(), event: 'Manual Sync Completed', source: 'Admin', status: 'success', timestamp: 'Ahora mismo' }, ...logs]);
    }, 2000);
  };

  const handleRegisterWebhooks = () => {
    setLogs([{ id: Date.now().toString(), event: 'Webhooks Re-registered', source: 'Admin', status: 'success', timestamp: 'Ahora mismo' }, ...logs]);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Integraciones Externas</h1>
          <p className="text-slate-400 mt-1">Conecta tu ecosistema logístico y de ventas</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Shopify Card */}
        <div className="lg:col-span-2 space-y-6">
          <div className="dark-glass rounded-[2.5rem] p-8 border border-slate-800 relative overflow-hidden">
            <div className="absolute -right-20 -bottom-20 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl"></div>
            
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
              <div className="flex items-center gap-6">
                <div className="w-20 h-20 bg-white p-4 rounded-3xl shadow-xl shadow-slate-900/50 flex items-center justify-center">
                  <img src="https://upload.wikimedia.org/wikipedia/commons/e/e1/Shopify_Logo.png" alt="Shopify" className="w-full object-contain" />
                </div>
                <div>
                  <h3 className="text-2xl font-black">Shopify Admin API</h3>
                  <p className="text-slate-400 text-sm flex items-center gap-2">
                    {isConnected ? (
                      <span className="text-emerald-400 flex items-center gap-1 font-bold">
                        <CheckCircle2 size={14} /> Conectado: {context?.shopDomain}
                      </span>
                    ) : (
                      <span className="text-slate-500">No vinculado</span>
                    )}
                  </p>
                </div>
              </div>
              <div className="flex gap-3">
                {isConnected ? (
                  <>
                    <button 
                      onClick={handleManualSync}
                      disabled={isSyncing}
                      className="bg-slate-900 border border-slate-800 px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 hover:bg-slate-800 transition-all"
                    >
                      <RefreshCw size={14} className={isSyncing ? 'animate-spin' : ''} />
                      Sincronizar Pedidos
                    </button>
                    <button 
                      onClick={() => context?.setIsConnected(false)}
                      className="bg-red-500/10 text-red-500 border border-red-500/20 px-4 py-2 rounded-xl text-xs font-bold hover:bg-red-500 hover:text-white transition-all"
                    >
                      Desconectar
                    </button>
                  </>
                ) : (
                  <button 
                    onClick={() => context?.setIsConnected(true)}
                    className="blue-gradient px-6 py-2 rounded-xl text-xs font-black shadow-lg shadow-blue-500/20 hover:scale-105 active:scale-95 transition-all"
                  >
                    CONECTAR TIENDA
                  </button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-12 pt-8 border-t border-slate-800/50 relative z-10">
              <div className="bg-slate-950/50 p-4 rounded-2xl border border-slate-800">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Webhook Status</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold">{isConnected ? '3 Registered' : 'N/A'}</span>
                  {isConnected && <div className="w-2 h-2 bg-emerald-500 rounded-full shadow-[0_0_8px_rgba(16,185,129,0.5)]"></div>}
                </div>
              </div>
              <div className="bg-slate-950/50 p-4 rounded-2xl border border-slate-800">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Última Sincro</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold">{isConnected ? 'Hoy, 09:42 AM' : 'N/A'}</span>
                  <Clock className="text-slate-600" size={14} />
                </div>
              </div>
              <div className="bg-slate-950/50 p-4 rounded-2xl border border-slate-800">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">API Scopes</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold">{isConnected ? 'Read/Write Orders' : 'N/A'}</span>
                  <ShieldCheck className="text-blue-400" size={14} />
                </div>
              </div>
            </div>

            {isConnected && (
              <div className="mt-6 flex gap-4 relative z-10">
                <button 
                  onClick={handleRegisterWebhooks}
                  className="text-[10px] font-black uppercase text-blue-400 bg-blue-500/10 px-3 py-1.5 rounded-lg border border-blue-500/20 hover:bg-blue-500 hover:text-white transition-all"
                >
                  Registrar Webhooks Manualmente
                </button>
              </div>
            )}
          </div>

          {/* Airtable Card (Secondary Integration) */}
          <div className="dark-glass rounded-[2.5rem] p-8 border border-slate-800">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-slate-100 p-2 rounded-xl flex items-center justify-center">
                  <img src="https://icon.icepanel.io/Technology/svg/Airtable.svg" alt="Airtable" className="w-full" />
                </div>
                <div>
                  <h4 className="text-lg font-bold">Airtable Automation</h4>
                  <p className="text-xs text-slate-500 italic">Sincronización bidireccional de estados</p>
                </div>
              </div>
              <div className="bg-emerald-500/10 text-emerald-400 text-[10px] font-black px-2 py-1 rounded border border-emerald-500/20">
                ACTIVE
              </div>
            </div>
            <div className="flex items-center gap-2 text-xs font-mono text-slate-400 bg-slate-950 p-3 rounded-xl border border-slate-800">
              <Database size={14} className="text-slate-600" />
              Base: COD_Operations_2025 (ID: appXXXXXXXXX)
            </div>
          </div>
        </div>

        {/* Console / Event Logs */}
        <div className="dark-glass rounded-[2.5rem] p-8 border border-slate-800 flex flex-col h-full">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold flex items-center gap-2">
              <Terminal className="text-blue-400" size={18} /> Consola de Eventos
            </h3>
            <span className="text-[10px] font-black text-slate-600 bg-slate-800 px-2 py-0.5 rounded">DEBUG MODE</span>
          </div>
          
          <div className="flex-1 space-y-4 overflow-y-auto max-h-[600px] pr-2">
            {logs.map((log) => (
              <div key={log.id} className="p-4 rounded-2xl bg-slate-900/50 border border-slate-800/50 hover:bg-slate-800 transition-all group">
                <div className="flex justify-between items-start mb-2">
                  <span className={`text-[9px] font-black uppercase tracking-tighter px-1.5 rounded ${
                    log.status === 'success' ? 'bg-emerald-500/20 text-emerald-400' : 
                    log.status === 'warning' ? 'bg-orange-500/20 text-orange-400' : 'bg-red-500/20 text-red-400'
                  }`}>
                    {log.status}
                  </span>
                  <span className="text-[9px] font-bold text-slate-600">{log.timestamp}</span>
                </div>
                <p className="text-xs font-bold text-slate-300 group-hover:text-white transition-colors">{log.event}</p>
                <div className="flex items-center gap-2 mt-2 opacity-50 text-[10px] font-mono">
                  <Zap size={10} /> {log.source}
                </div>
              </div>
            ))}
          </div>

          <button 
            onClick={() => setLogs([])}
            className="mt-6 w-full py-3 rounded-xl text-[10px] font-black text-slate-500 hover:text-red-400 hover:bg-red-500/5 transition-all border border-dashed border-slate-800"
          >
            LIMPIAR CONSOLA
          </button>
        </div>
      </div>
    </div>
  );
};

export default Integrations;
