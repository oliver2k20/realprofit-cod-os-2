
import React from 'react';
import { 
  Server, 
  Database, 
  Globe, 
  Zap, 
  ShieldCheck, 
  Cpu, 
  Layers,
  Code2,
  Workflow
} from 'lucide-react';

const SystemArchitecture: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="text-center max-w-3xl mx-auto mb-12">
        <h1 className="text-4xl font-black mb-4">SaaS Technical Blueprint</h1>
        <p className="text-slate-400">Arquitectura profesional diseñada para alta disponibilidad, escalabilidad (200+ órdenes/día) e integridad financiera.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Hosting Block */}
        <div className="dark-glass p-8 rounded-[2rem] border border-blue-500/20 relative">
          <div className="w-12 h-12 blue-gradient rounded-xl flex items-center justify-center mb-6 shadow-lg shadow-blue-500/40">
            <Globe className="text-white" size={24} />
          </div>
          <h3 className="text-xl font-bold mb-4">Cloud Infrastructure</h3>
          <p className="text-sm text-slate-400 leading-relaxed mb-6">
            <strong>Recomendación: Railway / Vercel</strong><br/>
            Escalabilidad instantánea, despliegue global de Edge Functions para validación de Webhooks rápida y base de datos relacional Postgres integrada.
          </p>
          <ul className="space-y-2 text-xs font-medium text-slate-300">
            <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div> Autoscale por CPU/RAM</li>
            <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div> Backups automáticos 24h</li>
            <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div> DDoS Protection (Cloudflare)</li>
          </ul>
        </div>

        {/* Database Block */}
        <div className="dark-glass p-8 rounded-[2rem] border border-emerald-500/20">
          <div className="w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center mb-6 shadow-lg shadow-emerald-500/40">
            <Database className="text-white" size={24} />
          </div>
          <h3 className="text-xl font-bold mb-4">Hybrid Storage</h3>
          <p className="text-sm text-slate-400 leading-relaxed mb-6">
            <strong>CRM: Airtable API</strong><br/>
            <strong>Core: Supabase (PostgreSQL)</strong><br/>
            Usamos Airtable como capa operativa (fácil para humanos) y PostgreSQL para lógica financiera pesada e índices de búsqueda.
          </p>
          <ul className="space-y-2 text-xs font-medium text-slate-300">
            <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div> Webhook Sockets (Realtime)</li>
            <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div> Row Level Security (RLS)</li>
            <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div> JSONB para Shopify Payloads</li>
          </ul>
        </div>

        {/* Logic Block */}
        <div className="dark-glass p-8 rounded-[2rem] border border-purple-500/20">
          <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center mb-6 shadow-lg shadow-purple-500/40">
            <Workflow className="text-white" size={24} />
          </div>
          <h3 className="text-xl font-bold mb-4">Event-Driven Workers</h3>
          <p className="text-sm text-slate-400 leading-relaxed mb-6">
            <strong>Next.js API + BullMQ</strong><br/>
            Manejo de colas para llamadas (Twilio/Zapier), validación HMAC de Shopify y cálculos de margen real asíncronos para no bloquear la UI.
          </p>
          <ul className="space-y-2 text-xs font-medium text-slate-300">
            <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-purple-500 rounded-full"></div> Reintentos exponenciales</li>
            <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-purple-500 rounded-full"></div> Webhook Deduplication</li>
            <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-purple-500 rounded-full"></div> Risk Scoring AI (Gemini)</li>
          </ul>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Webhook Code Example */}
        <div className="dark-glass rounded-[2rem] overflow-hidden border border-slate-800">
           <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
              <div className="flex items-center gap-2">
                <Code2 size={20} className="text-blue-400" />
                <span className="text-sm font-bold">Shopify Webhook Handler (Secure)</span>
              </div>
              <span className="text-[10px] bg-blue-500/20 text-blue-400 px-2 py-0.5 rounded-full font-bold">NODE.JS / NEXT.JS</span>
           </div>
           <div className="p-6 bg-slate-950/80 font-mono text-[11px] leading-relaxed text-blue-100/80">
              <pre>{`// hmac-validator.ts
import crypto from 'crypto';

export function validateShopifySignature(rawBody: string, hmac: string) {
  const secret = process.env.SHOPIFY_API_SECRET;
  const hash = crypto
    .createHmac('sha256', secret)
    .update(rawBody, 'utf8')
    .digest('base64');
  
  return hash === hmac;
}

// pages/api/webhooks/order-create.ts
export default async function handler(req, res) {
  const hmac = req.headers['x-shopify-hmac-sha256'];
  const rawBody = await getRawBody(req);

  if (!validateShopifySignature(rawBody, hmac)) {
    return res.status(401).send('Unauthorized');
  }

  // logic: Add to Supabase -> Trigger Airtable Sync -> Notify Slack
  await processOrder(JSON.parse(rawBody));
  res.status(200).send('OK');
}`}</pre>
           </div>
        </div>

        {/* Roadmap */}
        <div className="dark-glass p-8 rounded-[2rem] border border-slate-800">
          <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
            <Layers className="text-blue-400" size={24} /> Roadmap Comercial
          </h3>
          <div className="space-y-6">
            {[
              { t: 'Phase 1: Foundation', d: 'MVP con sincronización Shopify <-> Airtable y Dashboard financiero básico.', done: true },
              { t: 'Phase 2: Automation', d: 'Integración de telefonía para confirmaciones automáticas (Voz AI) y Score de riesgo.', done: false },
              { t: 'Phase 3: Multi-Carrier', d: 'Integración con APIs logísticas (Servientrega, Interrapidisimo, BlueExpress) para tracking real.', done: false },
              { t: 'Phase 4: SaaS Scaling', d: 'White-labeling, soporte multi-usuario, sub-cuentas para call centers y App móvil.', done: false },
            ].map((step, i) => (
              <div key={i} className={`flex gap-4 p-4 rounded-2xl ${step.done ? 'bg-blue-500/5' : 'bg-slate-900/30'}`}>
                <div className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${step.done ? 'bg-blue-500 text-white' : 'bg-slate-800 text-slate-500'}`}>
                  {i + 1}
                </div>
                <div>
                  <h4 className={`text-sm font-bold ${step.done ? 'text-blue-400' : 'text-slate-300'}`}>{step.t}</h4>
                  <p className="text-xs text-slate-500 mt-1">{step.d}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SystemArchitecture;
