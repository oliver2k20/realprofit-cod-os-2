
import React from 'react';
import { 
  TrendingUp, 
  ShoppingBag, 
  CheckCircle2, 
  XCircle, 
  PhoneCall, 
  Truck, 
  PackageCheck,
  DollarSign,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area 
} from 'recharts';

const data = [
  { name: '08:00', orders: 4, profit: 120 },
  { name: '10:00', orders: 12, profit: 340 },
  { name: '12:00', orders: 25, profit: 890 },
  { name: '14:00', orders: 18, profit: 620 },
  { name: '16:00', orders: 32, profit: 1100 },
  { name: '18:00', orders: 45, profit: 1540 },
  { name: '20:00', orders: 28, profit: 980 },
];

const StatCard = ({ title, value, icon: Icon, color, trend, trendValue }: any) => (
  <div className="dark-glass rounded-2xl p-6 transition-transform hover:scale-[1.02]">
    <div className="flex justify-between items-start mb-4">
      <div className={`p-3 rounded-xl ${color} bg-opacity-10 text-opacity-100`}>
        <Icon size={24} className={color.replace('bg-', 'text-')} />
      </div>
      {trend && (
        <div className={`flex items-center gap-1 text-xs font-bold ${trend === 'up' ? 'text-green-400' : 'text-red-400'}`}>
          {trend === 'up' ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}
          {trendValue}
        </div>
      )}
    </div>
    <p className="text-slate-400 text-sm font-medium">{title}</p>
    <h3 className="text-3xl font-extrabold mt-1">{value}</h3>
  </div>
);

const Dashboard: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Real-Time Performance</h1>
          <p className="text-slate-400 mt-1">Monitoreo operativo de hoy • Actualizado hace 2 min</p>
        </div>
        <div className="flex gap-3">
          <div className="bg-slate-900 border border-slate-800 px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            Sincronizado con Shopify
          </div>
        </div>
      </div>

      {/* Main Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Órdenes" value="124" icon={ShoppingBag} color="bg-blue-500" trend="up" trendValue="+12%" />
        <StatCard title="Confirmadas" value="82" icon={CheckCircle2} color="bg-emerald-500" trend="up" trendValue="+5%" />
        <StatCard title="Pendientes Llamada" value="28" icon={PhoneCall} color="bg-orange-500" />
        <StatCard title="Entregadas" value="56" icon={PackageCheck} color="bg-indigo-500" trend="up" trendValue="+8%" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="% Confirmación" value="78.2%" icon={TrendingUp} color="bg-blue-400" />
        <StatCard title="% Entrega" value="91.5%" icon={Truck} color="bg-purple-500" />
        <StatCard title="Ganancia Neta Hoy" value="$1,842.00" icon={DollarSign} color="bg-green-500" trend="up" trendValue="+22%" />
        <StatCard title="Pérdidas x Envíos" value="$215.40" icon={AlertTriangle} color="bg-red-500" trend="down" trendValue="-4%" />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="dark-glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-bold">Volumen de Órdenes</h3>
            <select className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-1 text-xs">
              <option>Últimas 24 Horas</option>
              <option>Ayer</option>
            </select>
          </div>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorOrders" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="name" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px' }}
                  itemStyle={{ color: '#f8fafc' }}
                />
                <Area type="monotone" dataKey="orders" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorOrders)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="dark-glass rounded-2xl p-6">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-bold">Ganancia Proyectada</h3>
            <div className="flex gap-2">
              <span className="flex items-center gap-1 text-xs text-green-400 font-bold bg-green-500/10 px-2 py-1 rounded-lg">
                <ArrowUpRight size={12} /> +$450.00
              </span>
            </div>
          </div>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="name" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px' }}
                  itemStyle={{ color: '#f8fafc' }}
                />
                <Bar dataKey="profit" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
