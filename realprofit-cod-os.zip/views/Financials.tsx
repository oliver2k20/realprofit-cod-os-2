
import React from 'react';
import { 
  PiggyBank, 
  ArrowUpRight, 
  CreditCard, 
  Wallet, 
  PieChart, 
  History,
  TrendingUp
} from 'lucide-react';

const Financials: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in zoom-in duration-500">
       <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Análisis Financiero</h1>
          <p className="text-slate-400 mt-1">Margen Real y Proyección de Rentabilidad</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          {/* Main Profit Card */}
          <div className="blue-gradient p-8 rounded-[2rem] relative overflow-hidden shadow-2xl shadow-blue-500/10">
            <div className="absolute -right-20 -top-20 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
            <div className="relative z-10">
              <div className="flex justify-between items-start mb-12">
                <div>
                  <p className="text-blue-100 font-medium mb-1">Balance Neto Real (30D)</p>
                  <h2 className="text-5xl font-black text-white">$42,850.42</h2>
                </div>
                <div className="bg-white/20 backdrop-blur-md p-3 rounded-2xl">
                  <TrendingUp className="text-white" size={32} />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-8 pt-8 border-t border-white/10">
                <div>
                  <p className="text-blue-100/70 text-xs font-bold uppercase tracking-wider mb-2">COGS Acumulado</p>
                  <p className="text-xl font-bold text-white">$12,450</p>
                </div>
                <div>
                  <p className="text-blue-100/70 text-xs font-bold uppercase tracking-wider mb-2">CPA Promedio</p>
                  <p className="text-xl font-bold text-white">$8.45</p>
                </div>
                <div>
                  <p className="text-blue-100/70 text-xs font-bold uppercase tracking-wider mb-2">ROI Logístico</p>
                  <p className="text-xl font-bold text-white">4.2x</p>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="dark-glass p-6 rounded-2xl">
              <h4 className="text-slate-400 text-sm font-bold mb-4 uppercase tracking-wider">Top Gastos</h4>
              <div className="space-y-4">
                {[
                  { label: 'Envios Fallidos', val: '$1,240', pct: '12%', color: 'bg-red-500' },
                  { label: 'Publicidad Meta', val: '$5,800', pct: '45%', color: 'bg-blue-500' },
                  { label: 'Costo de Producto', val: '$4,500', pct: '35%', color: 'bg-emerald-500' },
                  { label: 'Plataformas SaaS', val: '$320', pct: '8%', color: 'bg-purple-500' },
                ].map(item => (
                  <div key={item.label} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="font-semibold">{item.label}</span>
                      <span className="font-bold">{item.val}</span>
                    </div>
                    <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div className={`h-full ${item.color}`} style={{ width: item.pct }}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="dark-glass p-6 rounded-2xl flex flex-col justify-center text-center">
              <div className="w-16 h-16 bg-blue-500/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <PieChart className="text-blue-400" size={32} />
              </div>
              <h3 className="text-xl font-bold mb-2">Margen Neto Promedio</h3>
              <p className="text-5xl font-black text-emerald-400">32.4%</p>
              <p className="text-slate-400 text-sm mt-4">+$4.2% respecto al mes anterior</p>
            </div>
          </div>
        </div>

        {/* Recent Transactions / Breakdown */}
        <div className="dark-glass rounded-[2rem] p-8 space-y-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold">Desglose por Orden</h3>
            <History className="text-slate-600" size={20} />
          </div>
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map(i => (
              <div key={i} className="flex items-center gap-4 p-4 rounded-2xl bg-slate-900/50 hover:bg-slate-800 transition-all border border-slate-800/50 cursor-pointer">
                <div className="w-12 h-12 bg-emerald-500/10 rounded-xl flex items-center justify-center text-emerald-400 font-bold">
                  +$
                </div>
                <div className="flex-1">
                  <p className="text-sm font-bold">Orden #892{i}</p>
                  <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Ayer, 08:32 PM</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-emerald-400">+$28.40</p>
                  <p className="text-[10px] text-slate-500">Neto</p>
                </div>
              </div>
            ))}
          </div>
          <button className="w-full py-4 rounded-2xl border-2 border-dashed border-slate-800 text-slate-500 text-xs font-bold hover:border-slate-600 hover:text-slate-400 transition-all">
            VER TODO EL HISTORIAL
          </button>
        </div>
      </div>
    </div>
  );
};

export default Financials;
