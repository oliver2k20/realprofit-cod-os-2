
import React from 'react';
import { 
  ShieldX, 
  Search, 
  UserPlus, 
  Trash2, 
  AlertCircle,
  BrainCircuit,
  Zap
} from 'lucide-react';

const Blacklist: React.FC = () => {
  return (
    <div className="space-y-8 animate-in slide-in-from-right-4 duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Blacklist AI Security</h1>
          <p className="text-slate-400 mt-1">Detección automática de fraudes y reincidentes de "No Pago"</p>
        </div>
        <button className="bg-red-500 px-6 py-2 rounded-xl text-sm font-bold shadow-lg shadow-red-600/20 flex items-center gap-2 hover:brightness-110 transition-all">
          <UserPlus size={18} /> Agregar Manualmente
        </button>
      </div>

      {/* AI Status Card */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 dark-glass rounded-[2rem] p-8 border border-red-500/20 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-10">
            <BrainCircuit size={120} />
          </div>
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-red-500/10 rounded-2xl flex items-center justify-center">
                <Zap className="text-red-500" size={24} />
              </div>
              <h3 className="text-2xl font-black">Escudo Inteligente Activo</h3>
            </div>
            <p className="text-slate-400 max-w-xl mb-8 leading-relaxed">
              Nuestro motor de IA analiza patrones de comportamiento, números de teléfono y direcciones para bloquear automáticamente órdenes de clientes con historial de cancelaciones masivas o reportes de fraude.
            </p>
            <div className="flex gap-12">
              <div>
                <p className="text-3xl font-black text-red-500">412</p>
                <p className="text-xs font-bold text-slate-500 uppercase mt-1">Clientes Bloqueados</p>
              </div>
              <div>
                <p className="text-3xl font-black text-blue-500">$3,420</p>
                <p className="text-xs font-bold text-slate-500 uppercase mt-1">Pérdida Evitada (Estimada)</p>
              </div>
              <div>
                <p className="text-3xl font-black text-emerald-500">99.8%</p>
                <p className="text-xs font-bold text-slate-500 uppercase mt-1">Precisión de Detección</p>
              </div>
            </div>
          </div>
        </div>
        <div className="dark-glass rounded-[2rem] p-8 flex flex-col items-center justify-center text-center">
          <AlertCircle size={48} className="text-orange-500 mb-4" />
          <h4 className="text-lg font-bold">Sincronización Global</h4>
          <p className="text-xs text-slate-500 mt-2">Tu blacklist está siendo compartida con la base de datos comunitaria de RealProfit para mejorar la seguridad de todos.</p>
        </div>
      </div>

      {/* Blacklist Table */}
      <div className="dark-glass rounded-2xl overflow-hidden">
        <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-900/30">
          <h3 className="font-bold">Clientes con Alto Riesgo</h3>
          <div className="flex items-center gap-2 bg-slate-950 px-4 py-2 rounded-xl border border-slate-800">
             <Search size={16} className="text-slate-600" />
             <input type="text" placeholder="Buscar por teléfono o cédula..." className="bg-transparent border-none outline-none text-xs" />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-800">
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Cliente</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Identificador</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase">Razón</th>
                <th className="px-6 py-4 text-xs font-bold text-slate-500 uppercase text-right">Acción</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {[
                { name: 'Ricardo Mendez', id: '310 455 23XX', reason: '3 Órdenes Rechazadas consecutivas' },
                { name: 'Sofia Vergara', id: '315 221 44XX', reason: 'Fraude reportado por Drophi' },
                { name: 'Mateo Caseres', id: '300 111 22XX', reason: 'Dirección inexistente recurrente' },
              ].map((row, i) => (
                <tr key={i} className="hover:bg-red-500/5 transition-colors">
                  <td className="px-6 py-4 font-bold text-sm">{row.name}</td>
                  <td className="px-6 py-4 font-mono text-xs text-slate-400">{row.id}</td>
                  <td className="px-6 py-4">
                    <span className="px-3 py-1 bg-red-500/10 text-red-500 text-[10px] font-black uppercase rounded-full">
                      {row.reason}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button className="p-2 text-slate-600 hover:text-red-500 transition-all">
                      <Trash2 size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Blacklist;
