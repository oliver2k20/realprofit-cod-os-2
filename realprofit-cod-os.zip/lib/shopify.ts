
/**
 * @file lib/shopify.ts
 * Core logic for Shopify Admin API and Security
 */

export const SHOPIFY_API_VERSION = '2024-04';

/**
 * Verifies the integrity of Shopify Webhooks
 * This prevents spoofing attacks.
 */
export function verifyShopifyHmac(rawBody: string, hmacHeader: string): boolean {
  // In a real Node environment:
  // const crypto = require('crypto');
  // const secret = process.env.SHOPIFY_API_SECRET;
  // const hash = crypto.createHmac('sha256', secret).update(rawBody, 'utf8').digest('base64');
  // return hash === hmacHeader;
  
  // Dummy check for browser demo, replace with crypto in actual deployment
  return hmacHeader !== undefined;
}

/**
 * Generic Fetch wrapper for Shopify REST Admin API
 */
export async function shopifyFetch(shop: string, token: string, path: string, options: any = {}) {
  const url = `https://${shop}/admin/api/${SHOPIFY_API_VERSION}/${path}`;
  
  const headers = {
    'X-Shopify-Access-Token': token,
    'Content-Type': 'application/json',
    ...options.headers
  };

  const response = await fetch(url, { ...options, headers });
  
  if (!response.ok) {
    const errorBody = await response.text();
    throw new Error(`Shopify API Error (${response.status}): ${errorBody}`);
  }

  return response.json();
}

/**
 * Transforms a Shopify Order to our COD OS Schema
 */
export function transformShopifyOrder(shopifyOrder: any) {
  return {
    order_id: shopifyOrder.name,
    shopify_id: shopifyOrder.id.toString(),
    created_at: shopifyOrder.created_at,
    customer_name: `${shopifyOrder.customer?.first_name || ''} ${shopifyOrder.customer?.last_name || ''}`.trim(),
    phone: shopifyOrder.phone || shopifyOrder.customer?.phone || '',
    city: shopifyOrder.shipping_address?.city || '',
    total_price: parseFloat(shopifyOrder.total_price),
    status: 'Sin Confirmar', // Default for COD
    currency: shopifyOrder.currency,
    line_items: shopifyOrder.line_items.map((item: any) => ({
      name: item.name,
      sku: item.sku,
      quantity: item.quantity,
      price: item.price
    }))
  };
}
