
import React, { useState, createContext, useContext } from 'react';
import { 
  LayoutDashboard, 
  Package, 
  BarChart3, 
  ShieldAlert, 
  Settings, 
  LogOut, 
  Bell, 
  Search,
  Zap,
  AlertCircle,
  Link2,
  Share2
} from 'lucide-react';
import Dashboard from './views/Dashboard';
import Orders from './views/Orders';
import Financials from './views/Financials';
import Blacklist from './views/Blacklist';
import SystemArchitecture from './views/SystemArchitecture';
import Integrations from './views/Integrations';

// Contexto para manejar la conexión global de Shopify
interface ShopifyContextType {
  isConnected: boolean;
  setIsConnected: (val: boolean) => void;
  shopDomain: string;
  setShopDomain: (val: string) => void;
}

export const ShopifyContext = createContext<ShopifyContextType | undefined>(undefined);

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'orders' | 'financials' | 'blacklist' | 'architecture' | 'integrations'>('dashboard');
  const [isConnected, setIsConnected] = useState(false);
  const [shopDomain, setShopDomain] = useState('');

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'orders', label: 'Pedidos & Guías', icon: Package },
    { id: 'financials', label: 'Finanzas COD', icon: BarChart3 },
    { id: 'blacklist', label: 'Blacklist AI', icon: ShieldAlert },
    { id: 'integrations', label: 'Integraciones', icon: Share2 },
    { id: 'architecture', label: 'Arquitectura', icon: Zap },
  ];

  return (
    <ShopifyContext.Provider value={{ isConnected, setIsConnected, shopDomain, setShopDomain }}>
      <div className="flex h-screen bg-slate-950 text-slate-100 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-64 border-r border-slate-800 bg-slate-900/50 flex flex-col shrink-0">
          <div className="p-6 flex items-center gap-3">
            <div className="w-10 h-10 blue-gradient rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Package className="text-white" size={24} />
            </div>
            <span className="text-xl font-bold tracking-tight">RealProfit<span className="text-blue-500">COD</span></span>
          </div>

          <nav className="flex-1 px-4 py-4 space-y-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as any)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group ${
                  activeTab === item.id 
                    ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20 shadow-sm' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
                }`}
              >
                <item.icon size={20} className={activeTab === item.id ? 'text-blue-400' : 'group-hover:text-slate-100'} />
                <span className="font-medium">{item.label}</span>
              </button>
            ))}
          </nav>

          <div className="p-4 border-t border-slate-800 space-y-2">
            <div className="px-4 py-3 bg-slate-900 rounded-xl border border-slate-800 mb-2">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Shopify Sync</span>
                <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]' : 'bg-red-500'}`}></div>
              </div>
              <p className="text-[11px] text-slate-400 truncate font-mono">
                {isConnected ? shopDomain : 'Desconectado'}
              </p>
            </div>
            <button className="w-full flex items-center gap-3 px-4 py-3 text-red-400 hover:bg-red-500/10 rounded-xl transition-all">
              <LogOut size={20} />
              <span className="font-medium">Cerrar Sesión</span>
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 flex flex-col overflow-hidden relative">
          {!isConnected && activeTab !== 'integrations' && (
            <div className="bg-orange-500/10 border-b border-orange-500/20 px-8 py-2 flex items-center justify-between animate-pulse">
              <div className="flex items-center gap-2 text-orange-400 text-xs font-bold uppercase tracking-wider">
                <AlertCircle size={14} />
                Acceso Limitado: Sincronización con Shopify requerida para operaciones manuales
              </div>
              <button 
                onClick={() => setActiveTab('integrations')}
                className="text-[10px] bg-orange-500 text-white px-3 py-1 rounded-full font-black hover:brightness-110 transition-all"
              >
                CONECTAR AHORA
              </button>
            </div>
          )}

          {/* Header */}
          <header className="h-20 border-b border-slate-800 flex items-center justify-between px-8 bg-slate-950/50 backdrop-blur-md sticky top-0 z-10">
            <div className="flex items-center gap-4 bg-slate-900/80 px-4 py-2 rounded-full border border-slate-800 w-96">
              <Search size={18} className="text-slate-500" />
              <input 
                type="text" 
                placeholder="Buscar pedidos, clientes, guías..." 
                className="bg-transparent border-none outline-none text-sm w-full placeholder:text-slate-600"
              />
            </div>
            
            <div className="flex items-center gap-4">
              <button className="p-2.5 rounded-full hover:bg-slate-800 text-slate-400 transition-all relative">
                <Bell size={20} />
                <span className="absolute top-2 right-2.5 w-2 h-2 bg-blue-500 rounded-full border-2 border-slate-950"></span>
              </button>
              <div className="flex items-center gap-3 pl-4 border-l border-slate-800">
                <div className="text-right hidden sm:block">
                  <p className="text-sm font-semibold">Admin Tienda</p>
                  <p className="text-xs text-blue-400">Premium Plan</p>
                </div>
                <img src="https://picsum.photos/40/40" alt="Avatar" className="w-10 h-10 rounded-full border-2 border-slate-800" />
              </div>
            </div>
          </header>

          {/* View Router */}
          <div className="flex-1 overflow-y-auto p-8">
            {activeTab === 'dashboard' && <Dashboard />}
            {activeTab === 'orders' && <Orders />}
            {activeTab === 'financials' && <Financials />}
            {activeTab === 'blacklist' && <Blacklist />}
            {activeTab === 'architecture' && <SystemArchitecture />}
            {activeTab === 'integrations' && <Integrations />}
          </div>
        </main>
      </div>
    </ShopifyContext.Provider>
  );
};

export default App;
