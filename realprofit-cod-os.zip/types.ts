
export enum OrderStatus {
  UNCONFIRMED = 'Sin Confirmar',
  PENDING_CALL = 'Pendiente Llamada',
  CONFIRMED = 'Confirmado',
  SHIPPED = 'Enviado',
  DELIVERED = 'Entregado',
  CANCELLED = 'Cancelado',
  FAILED = 'Falla Entrega'
}

export enum RiskLevel {
  LOW = 'Bajo',
  MEDIUM = 'Medio',
  HIGH = 'Alto',
  BLACKLISTED = 'Blacklist'
}

export interface Order {
  id: string;
  shopifyId: string;
  customerName: string;
  phone: string;
  city: string;
  status: OrderStatus;
  total: number;
  cogs: number;
  cpa: number;
  shippingCost: number;
  netProfit: number;
  riskScore: number;
  riskLevel: RiskLevel;
  createdAt: string;
}

export interface DailyMetrics {
  totalOrders: number;
  confirmedCount: number;
  cancelledCount: number;
  pendingCallCount: number;
  shippedCount: number;
  deliveredCount: number;
  confirmationRate: number;
  deliveryRate: number;
  aov: number;
  realDailyProfit: number;
  failedShippingLoss: number;
}
