
/**
 * @file api/shopify/webhooks/register.ts
 * Automated webhook registration for the app
 */

import { shopifyFetch } from '../../../lib/shopify';

const WEBHOOKS = [
  { topic: 'orders/create', address: `${process.env.APP_URL}/api/shopify/webhooks/handler` },
  { topic: 'orders/updated', address: `${process.env.APP_URL}/api/shopify/webhooks/handler` },
  { topic: 'orders/cancelled', address: `${process.env.APP_URL}/api/shopify/webhooks/handler` }
];

export default async function handler(req: any, res: any) {
  const { shop, token } = req.body;

  try {
    const results = [];
    for (const webhook of WEBHOOKS) {
      const result = await shopifyFetch(shop, token, 'webhooks.json', {
        method: 'POST',
        body: JSON.stringify({ webhook })
      });
      results.push(result);
    }

    return res.status(200).json({ success: true, registered: results });
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message });
  }
}
