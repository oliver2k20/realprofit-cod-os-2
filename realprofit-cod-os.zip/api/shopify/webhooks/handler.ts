
/**
 * @file api/shopify/webhooks/handler.ts
 * Real-time event receiver for Shopify updates
 */

import { verifyShopifyHmac, transformShopifyOrder } from '../../../lib/shopify';

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') return res.status(405).end();

  const hmac = req.headers['x-shopify-hmac-sha256'];
  const topic = req.headers['x-shopify-topic'];
  const shop = req.headers['x-shopify-shop-domain'];
  
  // 1. Verify Request
  if (!verifyShopifyHmac(req.body, hmac)) {
    return res.status(401).send('Unauthorized');
  }

  const payload = JSON.parse(req.body);

  try {
    switch (topic) {
      case 'orders/create':
        const order = transformShopifyOrder(payload);
        // await db.orders.create(order);
        // await airtable.sync(order);
        console.log(`New order ${order.order_id} received from ${shop}`);
        break;

      case 'orders/updated':
        // Handle status changes (fulfillment, tags, etc)
        break;

      case 'orders/cancelled':
        // Handle cancellations
        break;
    }

    return res.status(200).send('OK');
  } catch (err: any) {
    return res.status(500).send(err.message);
  }
}
