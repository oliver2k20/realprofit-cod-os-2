
/**
 * @file api/shopify/sync.ts (Next.js API Route)
 * Handles the "Sync Orders Now" functionality
 */

import { shopifyFetch, transformShopifyOrder } from '../../lib/shopify';

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') return res.status(405).end();

  const { shop, token } = req.body;

  try {
    // 1. Fetch last 50 orders from Shopify
    // We filter for "financial_status: pending" since COD orders usually arrive as pending
    const data = await shopifyFetch(shop, token, 'orders.json?status=open&limit=50&financial_status=pending');
    
    const transformedOrders = data.orders.map(transformShopifyOrder);

    // 2. Database Sync Logic (Conceptual)
    // await db.orders.upsertMany(transformedOrders);
    
    // 3. Airtable Sync Logic (Conceptual)
    // await airtable.sync(transformedOrders);

    return res.status(200).json({
      success: true,
      count: transformedOrders.length,
      orders: transformedOrders
    });
  } catch (error: any) {
    console.error('Sync Error:', error.message);
    return res.status(500).json({ success: false, error: error.message });
  }
}
